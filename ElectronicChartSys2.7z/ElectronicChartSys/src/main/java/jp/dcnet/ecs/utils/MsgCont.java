package jp.dcnet.ecs.utils;

public class MsgCont {
	
	public static final String ISHI_PASS = "「医者ID」と「パスワード」はしてください。";

}
